package prog.ud05.actividad511.coleccion;

public class Cliente {
 
  /**
   * Atributos de la clase
   */
  private String nombre;
  private String apellidos;
  private String dni;
  private static int edad;

  
  public Cliente() {
    
  }

  public String getNombre(){
    return null;
  }
  public String getApellidos(){
    return null;
  }
  public String getDni(){
    return null;
  }
  public int getEdad(){
    return 1;
  }
  public int compareTo(Cliente o) {
    return 0;
  }
}
