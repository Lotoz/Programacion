package prog.ud05.actividad511.coleccion;

public class TarjetaClaves {

  public TarjetaClaves() {
    // TODO Auto-generated constructor stub
  }

}
