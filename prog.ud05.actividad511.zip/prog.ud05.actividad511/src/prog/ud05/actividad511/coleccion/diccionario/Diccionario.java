package prog.ud05.actividad511.coleccion.diccionario;

public class Diccionario {

  public Diccionario() {
    // TODO Auto-generated constructor stub
  }

}
