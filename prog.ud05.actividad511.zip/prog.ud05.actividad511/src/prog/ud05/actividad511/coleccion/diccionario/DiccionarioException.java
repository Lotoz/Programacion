package prog.ud05.actividad511.coleccion.diccionario;

public class DiccionarioException {

  public DiccionarioException() {
    // TODO Auto-generated constructor stub
  }

}
