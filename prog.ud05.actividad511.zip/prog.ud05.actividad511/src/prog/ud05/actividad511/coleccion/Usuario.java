package prog.ud05.actividad511.coleccion;

public class Usuario {

  public Usuario() {
    // TODO Auto-generated constructor stub
  }

}
