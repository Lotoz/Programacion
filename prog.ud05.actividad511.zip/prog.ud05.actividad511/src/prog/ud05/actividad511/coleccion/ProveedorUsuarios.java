package prog.ud05.actividad511.coleccion;

public class ProveedorUsuarios {

  public ProveedorUsuarios() {
    // TODO Auto-generated constructor stub
  }

}
