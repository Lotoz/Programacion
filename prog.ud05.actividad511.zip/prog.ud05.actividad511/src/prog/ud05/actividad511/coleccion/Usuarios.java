package prog.ud05.actividad511.coleccion;

public class Usuarios {

  public Usuarios() {
    // TODO Auto-generated constructor stub
  }

}
