package prog.ud05.actividad511.proveedores;

import prog.ud05.actividad511.coleccion.Usuarios;

public class ProveedorUsuariosArchivoJSON {

  public ProveedorUsuariosArchivoJSON() {
  
  }

  public ProveedorUsuariosArchivoJSON(String archivo) {
    // TODO Auto-generated constructor stub
  }

  public Usuarios obtieneUsuarios() {
    // TODO Auto-generated method stub
    return null;
  }

}
