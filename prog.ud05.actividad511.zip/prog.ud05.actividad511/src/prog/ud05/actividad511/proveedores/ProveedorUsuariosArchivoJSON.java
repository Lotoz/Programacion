package prog.ud05.actividad511.proveedores;

public class ProveedorUsuariosArchivoJSON {

  public ProveedorUsuariosArchivoJSON() {
    // TODO Auto-generated constructor stub
  }

}
