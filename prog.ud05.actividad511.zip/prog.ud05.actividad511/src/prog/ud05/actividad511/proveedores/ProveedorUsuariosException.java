package prog.ud05.actividad511.proveedores;

public class ProveedorUsuariosException extends RuntimeException {

  public ProveedorUsuariosException() {
    // TODO Auto-generated constructor stub
  }

  public ProveedorUsuariosException(String message) {
    super(message);
    // TODO Auto-generated constructor stub
  }

  public ProveedorUsuariosException(Throwable cause) {
    super(cause);
    // TODO Auto-generated constructor stub
  }

  public ProveedorUsuariosException(String message, Throwable cause) {
    super(message, cause);
    // TODO Auto-generated constructor stub
  }

  public ProveedorUsuariosException(String message, Throwable cause, boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
    // TODO Auto-generated constructor stub
  }

}
