package prog.unidad04.practica406.libreria;

public class FechaException extends Exception {

  public FechaException(String message) {
  super(message);
 }
}

