package prog.unidad09.relacion01;

import java.util.Scanner;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.ext.Db4oException;
import com.db4o.ext.Db4oIOException;
import prog.unidad09.relacion01.datos.Poblacion;

public class ModificarPoblacionApp {

  public static final String RUTA = "db/poblaciones.db4o";

  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    System.out.println("Introduzca los datos para la modificacion");

    System.out.println("Código del pueblo a modificar: ");
    String codigo = sc.nextLine();

    System.out.println("¿Quiere modificar el número de vehiculos (v) o el de líneas telefónicas (l)?: ");
    String seleccion = sc.nextLine();

    ObjectContainer db = null;

    try {
      if (!seleccion.equalsIgnoreCase("v") && !seleccion.equalsIgnoreCase("l")) {
        throw new IllegalArgumentException();
      }

      db = Db4o.openFile(RUTA);
      Poblacion poblacionProto = new Poblacion(codigo, null, 0, 0, 0, 0, 0, 0);
      ObjectSet<Poblacion> poblacion = db.queryByExample(poblacionProto);

      if (poblacion.size() == 0) {
        System.out.printf("No existe ninguna poblacion con codigo %s", codigo);
      } else {
        if (seleccion.equalsIgnoreCase("v")) {
          System.out.println("Introduzca el nuevo valor para el campo vehiculos: ");
          int modificacion = Integer.parseInt(sc.nextLine());

          Poblacion poblacionMod = poblacion.next();
          poblacionMod.setVehiculos(modificacion);
          db.store(poblacionMod);
        } else {
          System.out.println("Introduzca el nuevo valor para el campo lineas telefonicas: ");
          int modificacion = Integer.parseInt(sc.nextLine());

          Poblacion poblacionMod = poblacion.next();
          poblacionMod.setLineasTelefonicas(modificacion);
          db.store(poblacionMod);
        }
        System.out.println("El registro se actualizo con exito");
      }
    } catch (Db4oException e) {
      e.printStackTrace();
    } catch (IllegalArgumentException e) {
      System.err.println("Seleccion de campo invalida. Terminando");
    } finally {
      try {
        db.close();
      } catch (Db4oIOException e) {
        e.printStackTrace();
      }
    }
  }
}