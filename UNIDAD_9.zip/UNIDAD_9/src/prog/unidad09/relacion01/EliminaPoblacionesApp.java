package prog.unidad09.relacion01;

import java.util.Scanner;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.ext.Db4oException;
import com.db4o.ext.Db4oIOException;
import com.db4o.query.Predicate;

import prog.unidad09.relacion01.datos.Poblacion;

public class EliminaPoblacionesApp {

  public static final String RUTA = "db/poblaciones.db4o";

  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    System.out.println("Eliminacion de pueblos");

    System.out.println("¿Desea eliminar por código(c), extensión(e) o población total(p)?: ");
    String seleccion = sc.nextLine();

    ObjectContainer db = null;

    try {
      db = Db4o.openFile(RUTA);

      if (seleccion.equalsIgnoreCase("c")) {
        System.out.println("Código del pueblo a eliminar: ");
        String resultadoSeleccion = sc.nextLine();

        Poblacion poblacionProto = new Poblacion(resultadoSeleccion, null, 0, 0, 0, 0, 0, 0);
        ObjectSet<Poblacion> poblacion = db.queryByExample(poblacionProto);
        int numResultados = poblacion.size();
        if (numResultados == 0) {
          System.out.printf("No existe ninguna poblacion con codigo %s", resultadoSeleccion);
        } else {
          db.delete(poblacion.next());
          imprimirConfirmacion(numResultados);
        }
      } else if (seleccion.equalsIgnoreCase("e")) {
        System.out.println("Extensión máxima de los pueblos a eliminar (los pueblos con una extensión por debajo de ésta serán eliminados): ");
        double resultadoSeleccion = Double.parseDouble(sc.nextLine());

        ObjectSet<Poblacion> poblaciones = db.query(new Predicate<Poblacion>() {
          @Override
          public boolean match(Poblacion candidato) {
            return candidato.getExtension() < resultadoSeleccion;
          }
        });
        int numResultados = poblaciones.size();
        for (Poblacion poblacion : poblaciones) {
          db.delete(poblacion);
        }
        imprimirConfirmacion(numResultados);
      } else if (seleccion.equalsIgnoreCase("p")) {
        System.out.println("Población mínima de los pueblos a eliminar (los pueblos con una población por encima de ésta serán eliminados): ");
        int resultadoSeleccion = Integer.parseInt(sc.nextLine());

        ObjectSet<Poblacion> poblaciones = db.query(new Predicate<Poblacion>() {
          @Override
          public boolean match(Poblacion candidato) {
            return candidato.getPoblacionTotal() > resultadoSeleccion;
          }
        });
        int numResultados = poblaciones.size();
        for (Poblacion poblacion : poblaciones) {
          db.delete(poblacion);
        }
        imprimirConfirmacion(numResultados);
      } else {
        throw new IllegalArgumentException();
      }
    } catch (Db4oException e) {
      e.printStackTrace();
    } catch (IllegalArgumentException e) {
      System.err.println("Seleccion de campo invalida. Terminando");
    } finally {
      try {
        db.close();
      } catch (Db4oIOException e) {
        e.printStackTrace();
      }
    }
  }

  private static void imprimirConfirmacion(int numResultados) {
    System.out.printf("Se eliminaron %d poblaciones", numResultados);
  }
}