package prog.unidad09.relacion01;

import java.util.Comparator;
import java.util.Scanner;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.ext.Db4oException;
import com.db4o.ext.Db4oIOException;
import com.db4o.query.Predicate;

import prog.unidad09.relacion01.datos.Poblacion;

public class ConsultaPoblacionesConOrdenApp {

  public static final String RUTA = "db/poblaciones.db4o";
  private static final int LONGITUD_CABECERA = 73;

  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    System.out.println("Introduzca los parametros de busqueda");

    System.out.println("Texto a buscar en el nombre (vacío para cualquier nombre): ");
    String nombre = sc.nextLine();

    System.out.println("Mostrar sólo poblaciones con un mínimo de habitantes igual a: ");
    int poblacionMin = Integer.parseInt(sc.nextLine());

    System.out.println("Mostrar sólo poblaciones con un máximo de habitantes igual a: ");
    int poblacionMax = Integer.parseInt(sc.nextLine());

    System.out
        .println("Ordenar por (0=no ordenar, 1=ordenar por nombre ascendente, 2=ordenar por nombre descendente): ");
    int orden = Integer.parseInt(sc.nextLine());

    ObjectContainer db = null;

    try {
      db = Db4o.openFile(RUTA);
      ObjectSet<Poblacion> poblaciones = db.query(new Predicate<Poblacion>() {
        @Override
        public boolean match(Poblacion candidato) {
          return candidato.getNombre().contains(nombre) && candidato.getPoblacionTotal() >= poblacionMin
              && candidato.getPoblacionTotal() <= poblacionMax;
        }
      }, new Comparator<Poblacion>() {

        @Override
        public int compare(Poblacion o1, Poblacion o2) {
          switch (orden) {
          case 0:
            return 0;
          case 1:
            return o1.getNombre().compareTo(o2.getNombre());
          case 2:
            return o2.getNombre().compareTo(o1.getNombre());
          }
          return 0;
        }
      });

      System.out.println("Poblaciones encontradas\n" + imprimirCabecera());

      for (Poblacion poblacion : poblaciones) {
        System.out.println(poblacion);
      }

    } catch (Db4oException e) {
      e.printStackTrace();
    } finally {
      try {
        db.close();
      } catch (Db4oIOException e) {
        e.printStackTrace();
      }
    }
  }

  private static String imprimirCabecera() {
    String cabecera = String.format("CODIGO           NOMBRE             EXT   P_TOT  P_HOM  P_MUJ VEHIC LINEAS%n");
    for (int i = 0; i <= LONGITUD_CABECERA; i++) {
      cabecera += "-";
    }
    return cabecera;
  }
}