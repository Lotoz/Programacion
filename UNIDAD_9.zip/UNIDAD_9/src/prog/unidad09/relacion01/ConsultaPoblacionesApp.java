package prog.unidad09.relacion01;

import java.util.Scanner;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.ext.Db4oException;
import com.db4o.ext.Db4oIOException;
import com.db4o.query.Predicate;

import prog.unidad09.relacion01.datos.Poblacion;

public class ConsultaPoblacionesApp {

  public static final String RUTA = "db/poblaciones.db4o";
  private static final int LONGITUD_CABECERA = 73;
  
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    System.out.println("Introduzca los parametros de busqueda");

    System.out.println("Nombre: ");
    String nombre = sc.nextLine();

    System.out.println("Poblacion minima: ");
    int poblacionMin = Integer.parseInt(sc.nextLine());

    System.out.println("Poblacion maxima: ");
    int poblacionMax = Integer.parseInt(sc.nextLine());

    ObjectContainer db = null;
    
    try {
      db = Db4o.openFile(RUTA);
      ObjectSet<Poblacion> poblaciones = db.query(new Predicate<Poblacion>() {
        @Override
        public boolean match(Poblacion candidato) {
          return candidato.getNombre().contains(nombre) && candidato.getPoblacionTotal() >= poblacionMin
              && candidato.getPoblacionTotal() <= poblacionMax;
        }
      });
      
      System.out.println("Poblaciones encontradas\n" + imprimirCabecera());
      
      for (Poblacion poblacion : poblaciones) {
        System.out.println(poblacion);
      }

    } catch (Db4oException e) {
      e.printStackTrace();
    } finally {
      try {
        db.close();
      } catch (Db4oIOException e) {
        e.printStackTrace();
      }
    }
  }
  
  private static String imprimirCabecera() {
    String cabecera = String.format("CODIGO           NOMBRE             EXT   P_TOT  P_HOM  P_MUJ VEHIC LINEAS%n");
    for (int i = 0; i <= LONGITUD_CABECERA; i++) {
      cabecera += "-";
    }
    return cabecera;
  }
}