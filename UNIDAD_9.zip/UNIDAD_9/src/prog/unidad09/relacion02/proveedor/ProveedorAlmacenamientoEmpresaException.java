package prog.unidad09.relacion02.proveedor;

public class ProveedorAlmacenamientoEmpresaException extends RuntimeException {

  public ProveedorAlmacenamientoEmpresaException(String msg) {
    
  }
}
