package prog.unidad09.relacion02.proveedor.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.ext.Db4oException;
import com.db4o.ext.Db4oIOException;

import prog.unidad09.relacion02.datos.Centro;
import prog.unidad09.relacion02.datos.Departamento;
import prog.unidad09.relacion02.datos.Empleado;
import prog.unidad09.relacion02.proveedor.ProveedorAlmacenamientoEmpresa;
import prog.unidad09.relacion02.proveedor.ProveedorAlmacenamientoEmpresaException;

public class ProveedorAlmacenamientoEmpresaDb4o implements ProveedorAlmacenamientoEmpresa {

  private ObjectContainer db;
  private String rutaDb;

  public ProveedorAlmacenamientoEmpresaDb4o(String rutaDb) {
    this.rutaDb = rutaDb;
  }

  @Override
  public Centro getCentroByCodigo(int codigo) {

    try {
      db = Db4o.openFile(rutaDb);
      Centro centro = new Centro(codigo, null);
      ObjectSet<Centro> resultado = db.queryByExample(centro);
      if (resultado.hasNext()) {
        return resultado.next();
      }
    } catch (Db4oException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Ocurrió algún error accediendo al almacenamiento");
    } finally {
      cerrar();
    }

    return null;
  }

  @Override
  public List<Centro> getAllCentro(boolean ordenarPorNombre) {

    List<Centro> centros = new ArrayList<Centro>();

    try {
      db = Db4o.openFile(rutaDb);
      ObjectSet<Centro> resultado = db.query(Centro.class);

      if (ordenarPorNombre) {
        for (Centro centro : resultado) {
          centros.add(centro);
        }
        class ComparadorPorNombre implements Comparator<Centro> {

          public int compare(Centro s1, Centro s2) {
            return s1.getNombre().compareTo(s2.getNombre());

          }
        }
        centros.sort(new ComparadorPorNombre());
      } else {
        for (Centro centro : resultado) {
          centros.add(centro);
        }
      }
    } catch (Db4oException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Ocurrió algún error accediendo al almacenamiento");
    } finally {
      cerrar();
    }

    return centros;
  }

  @Override
  public Centro addCentro(Centro centro) {

    try {
      if (centro == null) {
        throw new NullPointerException("El centro no puede ser nulo");
      }
      db = Db4o.openFile(rutaDb);
      //No se si tengo que hacer que el codigo se genere de manera autoincremental teniendo en cuentas los codigos de la base de datos o tengo que hacerlo con un numero aleatorio.
      Centro centroSinCodigo = new Centro(0, centro.getNombre());
      db.store(centroSinCodigo);
      ObjectSet<Centro> resultado = db.queryByExample(centroSinCodigo);
      if (resultado.hasNext()) {
        return resultado.next();
      }
    } catch (Db4oException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Ocurrió algún error accediendo al almacenamiento");
    } catch (NullPointerException e) {
      System.err.println(e);
    } finally {
      cerrar();
    }
    return centro;
  }

  @Override
  public void updateCentro(Centro centro) {

    try {
      if (centro == null) {
        throw new NullPointerException("El centro no puede ser nulo");
      }

      if (getCentroByCodigo(centro.getNumero()) == null) {
        throw new ProveedorAlmacenamientoEmpresaException("No se ha encontrado un centro con el codigo introducido");
      }

      db.store(centro);
    } catch (Db4oIOException e) {
      System.err.println(e);
    } catch (ProveedorAlmacenamientoEmpresaException e) {
      System.err.println(e);
    } finally {
      cerrar();
    }
  }

  @Override
  public void deleteCentroByCodigo(int codigo) {
    try {
      Centro centro = getCentroByCodigo(codigo);

      if (centro == null) {
        throw new ProveedorAlmacenamientoEmpresaException("No se ha encontrado un centro con el codigo introducido");
      }
      db.delete(centro);
    } catch (Db4oIOException e) {
      System.err.println(e);
    } catch (ProveedorAlmacenamientoEmpresaException e) {
      System.err.println(e);
    } finally {
      cerrar();
    }
  }

  @Override
  public void cerrar() {
    try {
      db.close();
    } catch (Db4oException e) {
      System.err.println("Error al cerrar la conexion con la base de datos");
    }
  }

  @Override
  public List<Departamento> getAllDepartamento(boolean b) {
    List<Departamento> departamentos = new ArrayList<Departamento>();

    try {
      db = Db4o.openFile(rutaDb);
      ObjectSet<Departamento> resultado = db.query(Departamento.class);

      if (b) {
        for (Departamento departamento : resultado) {
          departamentos.add(departamento);
        }
        class ComparadorPorNombre implements Comparator<Departamento> {

          public int compare(Departamento s1, Departamento s2) {
            return s1.getNombre().compareTo(s2.getNombre());

          }
        }
        departamentos.sort(new ComparadorPorNombre());
      } else {
        for (Departamento departamento : resultado) {
          departamentos.add(departamento);
        }
      }
    } catch (Db4oException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Ocurrió algún error accediendo al almacenamiento");
    } finally {
      cerrar();
    }

    return departamentos;
  }

  @Override
  public Departamento getDepartamentoByCodigo(int codigo) {
    try {
      db = Db4o.openFile(rutaDb);
      Departamento departamento = new Departamento(codigo, null, null, 0, null, null, null);
      ObjectSet<Departamento> resultado = db.queryByExample(departamento);
      if (resultado.hasNext()) {
        return resultado.next();
      }
    } catch (Db4oException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Ocurrió algún error accediendo al almacenamiento");
    } finally {
      cerrar();
    }

    return null;
  }

  @Override
  public void addDepartamento(Departamento departamento) {
    try {
      if (departamento == null) {
        throw new NullPointerException("El departamento no puede ser nulo");
      }
      db = Db4o.openFile(rutaDb);
      Departamento departamentoSinCodigo = new Departamento(0, departamento.getNombre(), departamento.getDireccion(), departamento.getPresupuesto(), departamento.getCentro(),
          departamento.getDirector(), departamento.getDependeDe());
      db.store(departamentoSinCodigo);
    } catch (Db4oException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Ocurrió algún error accediendo al almacenamiento");
    } catch (NullPointerException e) {
      System.err.println(e);
    } finally {
      cerrar();
    }
  }

  @Override
  public Empleado getEmpleadoByCodigo(int codigoDirector) {
    try {
      db = Db4o.openFile(rutaDb);
      Empleado empleado = new Empleado(codigoDirector, null, null, null, null, 0, 0, 0, null);
      ObjectSet<Empleado> resultado = db.queryByExample(empleado);
      if (resultado.hasNext()) {
        return resultado.next();
      }
    } catch (Db4oException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Ocurrió algún error accediendo al almacenamiento");
    } finally {
      cerrar();
    }

    return null;
  }

  @Override
  public void updateDepartamento(Departamento departamento) {
    try {
      if (departamento == null) {
        throw new NullPointerException("El departamento no puede ser nulo");
      }

      if (getDepartamentoByCodigo(departamento.getNumero()) == null) {
        throw new ProveedorAlmacenamientoEmpresaException("No se ha encontrado un departamento con el codigo introducido");
      }

      db.store(departamento);
    } catch (Db4oIOException e) {
      System.err.println(e);
    } catch (ProveedorAlmacenamientoEmpresaException e) {
      System.err.println(e);
    } finally {
      cerrar();
    }
  }

  @Override
  public void deleteDepartamentoByCodigo(int codigo) {
    try {
      Departamento departamento = getDepartamentoByCodigo(codigo);

      if (departamento == null) {
        throw new ProveedorAlmacenamientoEmpresaException("No se ha encontrado un centro con el codigo introducido");
      }
      db.delete(departamento);
    } catch (Db4oIOException e) {
      System.err.println(e);
    } catch (ProveedorAlmacenamientoEmpresaException e) {
      System.err.println(e);
    } finally {
      cerrar();
    }
  }
}