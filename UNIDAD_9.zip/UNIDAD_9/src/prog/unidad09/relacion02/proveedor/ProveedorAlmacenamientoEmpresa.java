package prog.unidad09.relacion02.proveedor;

import java.util.List;

import prog.unidad09.relacion02.datos.Centro;
import prog.unidad09.relacion02.datos.Departamento;
import prog.unidad09.relacion02.datos.Empleado;

public interface ProveedorAlmacenamientoEmpresa {

  public Centro getCentroByCodigo(int codigo);

  public List<Centro> getAllCentro(boolean ordenarPorNombre);

  public Centro addCentro(Centro centro);

  public void updateCentro(Centro centro);

  public void deleteCentroByCodigo(int codigo);

  public void cerrar();

  public List<Departamento> getAllDepartamento(boolean b);

  public Departamento getDepartamentoByCodigo(int codigo);

  public void addDepartamento(Departamento departamento);

  public Empleado getEmpleadoByCodigo(int codigoDirector);

  public void updateDepartamento(Departamento departamento);

  public void deleteDepartamentoByCodigo(int codigo);

}
