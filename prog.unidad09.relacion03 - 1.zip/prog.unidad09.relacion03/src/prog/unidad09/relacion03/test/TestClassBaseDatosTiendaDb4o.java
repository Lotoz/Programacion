package prog.unidad09.relacion03.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import prog.ud09.actividad903.database.BaseDatosTiendaException;
import prog.ud09.actividad903.database.impl.BaseDatosTiendaDb4o;
import prog.unidad09.relacion03.datos.Cliente;
import prog.unidad09.relacion03.datos.Motocicleta;

public class TestClassBaseDatosTiendaDb4o {

    private BaseDatosTiendaDb4o baseDatos;

    @Before
    public void setUp() {
        // Inicializa la base de datos antes de cada prueba
        baseDatos = new BaseDatosTiendaDb4o("test.db4o");
    }

    @Test
    public void testAddMotocicleta() {
        Motocicleta moto = new Motocicleta("9RT45W3T41", 1000, "Deportiva", 15000.0, "Kawasaki");
        baseDatos.addMotocicleta(moto);
        
        // Verifica que la motocicleta se haya agregado correctamente
        Motocicleta motoRecuperada = baseDatos.getMotocicletaByReferencia("9RT45W3T43");
        assertNotNull(motoRecuperada);
        assertEquals("Kawasaki", motoRecuperada.getFabricante());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddMotocicletaDuplicada() {
        Motocicleta moto1 = new Motocicleta("123ABC", 1000, "Deportiva", 15000.0, "Kawasaki");
        Motocicleta moto2 = new Motocicleta("123ABC", 1000, "Deportiva", 15000.0, "Kawasaki");
        
        baseDatos.addMotocicleta(moto1);
        baseDatos.addMotocicleta(moto2); // Esto debería lanzar una excepción
    }

    @Test
    public void testGetClienteByNif() {
        Cliente cliente = new Cliente("12345678A", "Juan", "Pérez", "Calle Falsa 123", null);
        baseDatos.updateCliente(cliente); // Asegúrate de tener un método para agregar clientes

        Cliente clienteRecuperado = baseDatos.getClienteByNif("12345678A");
        assertNotNull(clienteRecuperado);
        assertEquals("Juan", clienteRecuperado.getNombre());
    }

    @Test
    public void testDeleteMotocicleta() throws BaseDatosTiendaException {
        Motocicleta moto = new Motocicleta("9RT45W3T44", 1000, "Deportiva", 15000.0, "Kawasaki");
        baseDatos.addMotocicleta(moto);
        
        baseDatos.deleteMotocicletaByReferencia("9RT45W3T44");
        
        // Verifica que la motocicleta ya no existe
        Motocicleta motoRecuperada = baseDatos.getMotocicletaByReferencia("9RT45W3T44");
        assertNull(motoRecuperada);
    }

    @Test(expected = BaseDatosTiendaException.class)
    public void testDeleteMotocicletaNoExistente() throws BaseDatosTiendaException {
        baseDatos.deleteMotocicletaByReferencia("NO_EXISTE"); // Esto debería lanzar una excepción
    }

    @After
    public void tearDown() {
        // Cierra la base de datos después de cada prueba
        baseDatos.cerrar();
    }
}