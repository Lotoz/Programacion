package prog.ud05.actividad511.coleccion;

public class UsuariosException extends RuntimeException {

  public UsuariosException(String message) {
    super(message);
  }

  public UsuariosException(String message, Throwable cause) {
    super(message, cause);
  }

}
