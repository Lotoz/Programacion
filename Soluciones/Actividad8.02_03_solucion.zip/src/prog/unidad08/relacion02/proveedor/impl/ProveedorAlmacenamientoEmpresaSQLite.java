package prog.unidad08.relacion02.proveedor.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import prog.unidad08.relacion02.entidades.Centro;
import prog.unidad08.relacion02.entidades.Departamento;
import prog.unidad08.relacion02.entidades.Empleado;
import prog.unidad08.relacion02.proveedor.ProveedorAlmacenamientoEmpresa;
import prog.unidad08.relacion02.proveedor.ProveedorAlmacenamientoEmpresaException;

/**
 * Proveedor de almacenamiento para la empresa en base de datos SQLite
 */
public class ProveedorAlmacenamientoEmpresaSQLite implements ProveedorAlmacenamientoEmpresa {

  // Constantes
  // URL Base para conectar con SQLite
  private static final String URL_BASE = "jdbc:sqlite:";
  // Sentencias SQL
  private static final String SQL_GET_CENTRO_BY_CODIGO = "SELECT * FROM centro WHERE numce = ?";
  private static final String SQL_GET_ALL_CENTRO = "SELECT * FROM centro";
  private static final String SQL_GET_ALL_CENTRO_ORDENADO = "SELECT * FROM centro ORDER BY nomce ASC";
  private static final String SQL_ADD_CENTRO = "INSERT INTO centro(nomce) VALUES (?)";
  private static final String SQL_UPDATE_CENTRO = "UPDATE centro SET nomce = ? WHERE numce = ?";
  private static final String SQL_DELETE_CENTRO = "DELETE FROM centro WHERE numce = ?";
  private static final String SQL_GET_DEPARTAMENTO_BY_CODIGO = "SELECT * FROM departamento WHERE numde = ?";
  private static final String SQL_GET_ALL_DEPARTAMENTO = "SELECT * FROM departamento";
  private static final String SQL_GET_ALL_DEPARTAMENTO_ORDENADO = "SELECT * FROM departamento ORDER BY nomde ASC";
  private static final String SQL_ADD_DEPARTAMENTO = "INSERT INTO departamento(numce, direc, tidir, presu, depde, nomde) VALUES (?, ?, ?, ?, ?, ?)";
  private static final String SQL_UPDATE_DEPARTAMENTO = "UPDATE departamento set numce = ?, direc = ?, tidir = ?, presu = ?, depde = ?, nomde = ? WHERE numde = ?";
  private static final String SQL_DELETE_DEPARTAMENTO = "DELETE FROM departamento WHERE numde = ?";
  private static final String SQL_GET_EMPLEADO_BY_CODIGO = "SELECT * FROM empleado WHERE numem = ?";
  
  // Campos de tabla centro
  private static final String C_CENTRO_CODIGO = "numce";
  private static final String C_CENTRO_NOMBRE = "nomce";
  
  // Campos de tabla departamento
  private static final String C_DPTO_CODIGO = "numde";
  private static final String C_DPTO_CENTRO = "numce";
  private static final String C_DPTO_DIRECTOR = "tidir";
  private static final String C_DPTO_DIRECCION = "direc";
  private static final String C_DPTO_PRESUPUESTO = "presu";
  private static final String C_DPTO_DEPENDE_DE_DEPARTAMENTO = "depde";
  private static final String C_DPTO_NOMBRE = "nomde";
  
  // Campos de tabla empleado
  private static final String C_EMPLEADO_CODIGO = "numem";
  private static final String C_EMPLEADO_DEPARTAMENTO = "numde";
  private static final String C_EMPLEADO_EXTENSION_TELEFONICA = "extel";
  private static final String C_EMPLEADO_FECHA_NACIMIENTO = "fecna";
  private static final String C_EMPLEADO_FECHA_INCORPORACION = "fecin";
  private static final String C_EMPLEADO_SALARIO = "salar";
  private static final String C_EMPLEADO_COMISION = "comis";
  private static final String C_EMPLEADO_NUMERO_HIJOS = "numhi";
  private static final String C_EMPLEADO_NOMBRE = "nomem";
  
  // Atributos
  // Ruta a la base de datos SQLite
  private String rutaDB;
  
  /**
   * Constructor
   * @param rutaDB Ruta a la base de datos a emplear.
   */
  public ProveedorAlmacenamientoEmpresaSQLite(String rutaDB) {
    this.rutaDB = rutaDB;
  }
  
  @Override
  public Centro getCentroByCodigo(int codigo) {
    // Obtenemos conexión y consulta
    try (Connection conexion = getConexion();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_GET_CENTRO_BY_CODIGO)) {
      // Rellenamos los parámetros de la sentencia
      sentencia.setInt(1, codigo);
      // Ejecuta la consulta
      ResultSet rs = sentencia.executeQuery();
      // Centro a devolver
      Centro centro = null;
      // Si se encontró el centro
      if (rs.next()) {
        // Lo obtiene
        centro = getCentroFromResultSet(rs); 
      }
      // Cierra el resultset
      rs.close();
      // Y devuelve el centro (o null)
      return centro;
    } catch (SQLException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Error JDBC en getCentroByCodigo: "
        + e.getMessage());
    }
  }

  @Override
  public List<Centro> getAllCentro(boolean ordenarPorNombre) {
    // Determinamos el SQL a emplear (ordenando o no)
    String sql = ordenarPorNombre ? SQL_GET_ALL_CENTRO_ORDENADO : SQL_GET_ALL_CENTRO;
    
    // Obtenemos conexión y consulta
    try (Connection conexion = getConexion();
         PreparedStatement sentencia = conexion.prepareStatement(sql)) {
      // Ejecuta la consulta
      ResultSet rs = sentencia.executeQuery();
      // Lista con los centros
      List<Centro> resultado = new ArrayList<>();
      // Para cada centro
      while (rs.next()) {
        // Lo obtiene y lo almacena
        resultado.add(getCentroFromResultSet(rs));
      }
      // Cierra el resultset
      rs.close();
      // Y devuelve el resultado
      return resultado;
    } catch (SQLException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Error JDBC en getAllCentro: "
        + e.getMessage());
    }
  }

  @Override
  public Centro addCentro(Centro centro) {
    // Obtenemos conexión y sentencia
    try (Connection conexion = getConexion();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_ADD_CENTRO
           , Statement.RETURN_GENERATED_KEYS)) {
      // Rellena el nombre (el código se genera automáticamente
      sentencia.setString(1, centro.getNombre());
      // Ejecuta la actualizacion
      sentencia.executeUpdate();
      // Obtenemos la clave
      ResultSet rs = sentencia.getGeneratedKeys();
      // Si hubo clave
      if (rs.next()) {
        centro = new Centro(rs.getInt(1), centro.getNombre());
      }
      // Cierra el resultset
      rs.close();
      // Y devuelve el centro
      return centro;
    } catch (SQLException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Error JDBC en addCentro: "
        + e.getMessage());
    }
  }

  @Override
  public void updateCentro(Centro centro) {
    // Obtenemos conexión y sentencia
    try (Connection conexion = getConexion();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_UPDATE_CENTRO)) {
      // Rellena el nombre y codigo
      sentencia.setString(1, centro.getNombre());
      sentencia.setInt(2, centro.getCodigo());
      // Ejecuta la actualizacion
      if (sentencia.executeUpdate() != 1) {
        throw new ProveedorAlmacenamientoEmpresaException("Error en updateCentro. El centro"
          + "indicado no existe en la base de datos");
      }
    } catch (SQLException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Error JDBC en updateCentro: "
        + e.getMessage());
    }
  }

  @Override
  public void deleteCentroByCodigo(int codigo) {
    // Obtenemos conexión y sentencia
    try (Connection conexion = getConexion();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_DELETE_CENTRO)) {
      // Rellena el codigo
      sentencia.setInt(1, codigo);
      // Ejecuta la actualizacion
      if (sentencia.executeUpdate() != 1) {
        throw new ProveedorAlmacenamientoEmpresaException("Error en deleteCentroByCodigo. El centro"
            + "indicado no existe en la base de datos");
      }
    } catch (SQLException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Error JDBC en deleteCentroByCodigo: "
        + e.getMessage());
    }
  }

  @Override
  public List<Departamento> getDepartamentoAll(boolean ordenarPorNombre) {
    // Determinamos el SQL a emplear (ordenando o no)
    String sql = ordenarPorNombre ? SQL_GET_ALL_DEPARTAMENTO_ORDENADO : SQL_GET_ALL_DEPARTAMENTO;
    
    // Obtenemos conexión y consulta
    try (Connection conexion = getConexion();
         PreparedStatement sentencia = conexion.prepareStatement(sql)) {
      // Ejecuta la consulta
      ResultSet rs = sentencia.executeQuery();
      // Lista con los departamentos
      List<Departamento> resultado = new ArrayList<>();
      // Para cada centro
      while (rs.next()) {
        // Lo obtiene y lo almacena
        resultado.add(getDepartamentoFromResultSet(rs));
      }
      // Cierra el resultset
      rs.close();
      // Y devuelve el resultado
      return resultado;
    } catch (SQLException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Error JDBC en getDepartamentoAll: "
        + e.getMessage());
    }
  }

  @Override
  public Departamento getDepartamentoByCodigo(int codigo) {
    // Obtenemos conexión y consulta
    try (Connection conexion = getConexion();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_GET_DEPARTAMENTO_BY_CODIGO)) {
      // Rellenamos los parámetros de la sentencia
      sentencia.setInt(1, codigo);
      // Ejecuta la consulta
      ResultSet rs = sentencia.executeQuery();
      // Departamento a devolver
      Departamento departamento = null;
      // Si se encontró el departamento
      if (rs.next()) {
        // Lo obtiene
        departamento = getDepartamentoFromResultSet(rs); 
      }
      // Cierra el resultset
      rs.close();
      // Y devuelve el departamento (o null)
      return departamento;
    } catch (SQLException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Error JDBC en getDepartamentoByCodigo: "
        + e.getMessage());
    }
  }

  @Override
  public Departamento addDepartamento(Departamento departamento) {
    // Obtenemos conexión y sentencia
    try (Connection conexion = getConexion();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_ADD_DEPARTAMENTO
           , Statement.RETURN_GENERATED_KEYS)) {
      // Rellena todos los campos menos el código que se genera automáticamente
      sentencia.setInt(1, departamento.getCodigoCentro());
      sentencia.setString(2, departamento.getDireccion());
      sentencia.setInt(3, departamento.getCodigoDirector());
      sentencia.setDouble(4, departamento.getPresupuesto());
      // En el caso del dapartamento superior puede ser null. De ahi el if-else
      if (departamento.getCodigoDepartamentoSuperior() != null) {
        sentencia.setInt(5, departamento.getCodigoDepartamentoSuperior());
      } else {
        sentencia.setNull(5, Types.INTEGER);
      }
      sentencia.setString(6, departamento.getNombre());
      
      // Ejecuta la actualizacion
      sentencia.executeUpdate();
      // Obtenemos la clave
      ResultSet rs = sentencia.getGeneratedKeys();
      // Si hubo clave
      if (rs.next()) {
        // Crea un departamento con los mismos datos y la clave generada
        departamento = new Departamento(rs.getInt(1), departamento.getNombre()
          , departamento.getCodigoCentro(), departamento.getDireccion()
          , departamento.getCodigoDirector(), departamento.getPresupuesto()
          , departamento.getCodigoDepartamentoSuperior());
      }
      // Cierra el resultset
      rs.close();
      // Y devuelve el departamento
      return departamento;
    } catch (SQLException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Error JDBC en addDepartamento: "
        + e.getMessage());
    }
  }

  @Override
  public void updateDepartamento(Departamento departamento) {
    // Obtenemos conexión y sentencia
    try (Connection conexion = getConexion();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_UPDATE_DEPARTAMENTO)) {
      // Rellena los campos a actualizar y por último el código
      sentencia.setInt(1, departamento.getCodigoCentro());
      sentencia.setString(2, departamento.getDireccion());
      sentencia.setInt(3, departamento.getCodigoDirector());
      sentencia.setDouble(4, departamento.getPresupuesto());
      // El campo depde puede ser null. De ahi el if-else
      if (departamento.getCodigoDepartamentoSuperior() != null) {
        sentencia.setInt(5, departamento.getCodigoDepartamentoSuperior());
      } else {
        sentencia.setNull(5, Types.INTEGER);
      }
      sentencia.setString(6, departamento.getNombre());
      // Por último el código del departamento a modificar
      sentencia.setInt(7, departamento.getCodigo());
      // Ejecuta la actualizacion
      if (sentencia.executeUpdate() != 1) {
        throw new ProveedorAlmacenamientoEmpresaException("Error en updateDepartamento. El "
          + "departamento indicado no existe en la base de datos");
      }
    } catch (SQLException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Error JDBC en updateDepartamento: "
        + e.getMessage());
    }
  }

  @Override
  public void deleteDepartamentoByCodigo(int codigo) {
    // Obtenemos conexión y sentencia
    try (Connection conexion = getConexion();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_DELETE_DEPARTAMENTO)) {
      // Rellena el codigo
      sentencia.setInt(1, codigo);
      // Ejecuta la actualizacion
      if (sentencia.executeUpdate() != 1) {
        throw new ProveedorAlmacenamientoEmpresaException("Error en deleteDepartamentoByCodigo. "
          + "El departamento indicado no existe en la base de datos");
      }
    } catch (SQLException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Error JDBC en deleteDepartamentoByCodigo: "
        + e.getMessage());
    }
  }

  @Override
  public Empleado getEmpleadoByCodigo(int codigo) {
    // Obtenemos conexión y consulta
    try (Connection conexion = getConexion();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_GET_EMPLEADO_BY_CODIGO)) {
      // Rellenamos los parámetros de la sentencia
      sentencia.setInt(1, codigo);
      // Ejecuta la consulta
      ResultSet rs = sentencia.executeQuery();
      // Empleado a devolver
      Empleado empleado = null;
      // Si se encontró el empleado
      if (rs.next()) {
        // Lo obtiene
        empleado = getEmpleadoFromResultSet(rs); 
      }
      // Cierra el resultset
      rs.close();
      // Y devuelve el empleado (o null)
      return empleado;
    } catch (SQLException e) {
      throw new ProveedorAlmacenamientoEmpresaException("Error JDBC en getEmpleadoByCodigo: "
        + e.getMessage());
    }
  }

  /**
   * Obtiene conexion a la base de datos
   * @return Conexión a la base de datos
   * @throws SQLException Si ocurre cualquier error accediendo a la base de datos
   */
  private Connection getConexion() throws SQLException {
    return DriverManager.getConnection(URL_BASE + rutaDB);
  }

  /**
   * Obtiene un centro a partir de un resultset sobre la tabla centro
   * @param rs ResultSet sobre la tabla centro
   * @return Centro con los datos de la fila actual del resultset
   * @throws SQLException Si ocurre cualquier error accediendo a la fila
   */
  private Centro getCentroFromResultSet(ResultSet rs) throws SQLException {
    return new Centro(rs.getInt(C_CENTRO_CODIGO), rs.getString(C_CENTRO_NOMBRE));
  }

  /**
   * Obtiene un departamento a partir de un resultset sobre la tabla departamento
   * @param rs ResultSet sobre la tabla departamento
   * @return Departamento con los datos de la fila actual del resultset
   * @throws SQLException Si ocurre cualquier error accediendo a la fila
   */
  private Departamento getDepartamentoFromResultSet(ResultSet rs) throws SQLException {
    // Obtiene el código del departamento al que pertenece
    Integer codigoDepartamentoSuperior = rs.getInt(C_DPTO_DEPENDE_DE_DEPARTAMENTO);
    // Si era null
    if (rs.wasNull()) {
      // Almacena null en la variable
      codigoDepartamentoSuperior = null;
    }
    // Crea y devuelve el departamento con los datos del resultset
    return new Departamento(rs.getInt(C_DPTO_CODIGO), rs.getString(C_DPTO_NOMBRE)
      , rs.getInt(C_DPTO_CENTRO), rs.getString(C_DPTO_DIRECCION), rs.getInt(C_DPTO_DIRECTOR)
      , rs.getDouble(C_DPTO_PRESUPUESTO), codigoDepartamentoSuperior);
  }

  /**
   * Obtiene un empleado a partir de un resultset sobre la tabla empleado
   * @param rs ResultSet sobre la tabla empleado
   * @return Empleado con los datos de la fila actual del resultset
   * @throws SQLException Si ocurre cualquier error accediendo a la fila
   */
  private Empleado getEmpleadoFromResultSet(ResultSet rs) throws SQLException {
    // Crea y devuelve el empleado con los datos del resultset
    return new Empleado(rs.getInt(C_EMPLEADO_CODIGO), rs.getString(C_EMPLEADO_NOMBRE)
      , rs.getString(C_EMPLEADO_EXTENSION_TELEFONICA), rs.getString(C_EMPLEADO_FECHA_NACIMIENTO)
      , rs.getString(C_EMPLEADO_FECHA_INCORPORACION), rs.getDouble(C_EMPLEADO_SALARIO)
      , rs.getDouble(C_EMPLEADO_COMISION), rs.getInt(C_EMPLEADO_NUMERO_HIJOS));
  }
}
