package prog.unidad09.relacion01.ejercicio01;

import java.util.Scanner;
import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import prog.unidad09.relacion01.datos.Poblacion;

/**
 * Añade una población a la base de datos con los datos aportados por el usuario
 */
public class PoblacionesAddApp {
  // Constantes
  // Ruta a la base de datos
  private static final String RUTA = "db/poblaciones.db4o";

  /**
   * Principal
   * @param args
   */
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
    // Solicita los datos al usuario
    System.out.println("Introduzca los datos de la nueva población");
    System.out.print("Codigo: ");
    String codigo = sc.nextLine();
    System.out.print("Nombre de la población: ");
    String nombre = sc.nextLine();
    System.out.print("Extensión (en km2): ");
    double extension = Double.parseDouble(sc.nextLine());
    System.out.print("Población (Hombres): ");
    int hombres = Integer.parseInt(sc.nextLine());
    System.out.print("Población (Mujeres): ");
    int mujeres = Integer.parseInt(sc.nextLine());
    System.out.print("Número de vehiculos: ");
    int vehiculos = Integer.parseInt(sc.nextLine());
    System.out.print("Número de líneas telefónicas: ");
    int lineas = Integer.parseInt(sc.nextLine());
    
    // Inserta el registro en la base de datos
    try {
      insertaPoblacion(codigo, nombre, extension, hombres, mujeres, vehiculos, lineas);
    } catch (Exception e) {
      // Si error lo muestra
      System.err.println("Ocurrió un error añadiendo la población: " + e);
    }
  }

  /**
   * Inserta la población en la base de datos
   * @param codigo Codigo de poblacion
   * @param nombre Nombre de población
   * @param extension Extensión de poblacion
   * @param hombres Número de hombres de la población
   * @param mujeres Número de mujeres de la población
   * @param vehiculos Número de vehículos de la población
   * @param lineas Número de líneas telefónicas de la población
   */
  private static void insertaPoblacion(String codigo, String nombre, double extension, int hombres,
    int mujeres, int vehiculos, int lineas) {
    // Base de datos
    ObjectContainer db = null;

    try {
      // Conectamos con la base de datos
      db = Db4o.openFile(RUTA);
      // Creamos la poblacion
      Poblacion poblacion = new Poblacion(codigo, nombre, extension, hombres + mujeres, hombres, mujeres, vehiculos, lineas);
      // La insertamos
      db.store(poblacion);
    } finally {
      try {
        // Y cerramos
        db.close();
      } catch (Exception e1) {}
    }
  }
}
