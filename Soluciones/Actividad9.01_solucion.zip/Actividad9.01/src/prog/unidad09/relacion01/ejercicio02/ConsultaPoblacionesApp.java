package prog.unidad09.relacion01.ejercicio02;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Predicate;
import prog.unidad09.relacion01.datos.Poblacion;

/**
 * Aplicación que realiza varias consultas sobre la base de datos y muestra los resultados por
 * pantalla
 */
public class ConsultaPoblacionesApp {
  
  // Constantes
  // Ruta a la base de datos
  private static final String RUTA = "db/poblaciones.db4o";

  /**
   * Programa principal
   * @param args
   */
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
    // Solicita los datos al usuario
    System.out.println("Introduzca los parámetros de búsqueda");
    System.out.print("Texto a buscar en el nombre (vacío para cualquier nombre): ");
    String nombre = sc.nextLine();
    System.out.print("Mostrar sólo poblaciones con un mínimo de habitantes igual a: ");
    int poblacionMinima = Integer.parseInt(sc.nextLine());
    System.out.print("Mostrar sólo poblaciones con un máximo de habitantes igual a: ");
    int poblacionMaxima = Integer.parseInt(sc.nextLine());
    
    try {
      // Obtenemos las poblaciones
      List<Poblacion> poblaciones = buscarPoblaciones(nombre, poblacionMinima, poblacionMaxima);
      // Y las imprimimos
      imprimePoblaciones(poblaciones);
    } catch (Exception e) {
      // En caso de error se muestra el mensaje
      System.err.println("Ocurrió un error realizando la búsqueda: " + e);
    }
  }

  /**
   * Busca poblaciones por nombre y número de habitantes
   * @param nombre Texto a buscar en el nombre de la población (vacío para todas)
   * @param poblacionMinima Población mínima que debe tener una población para entrar en los
   *   resultados
   * @param poblacionMaxima Poblacion máxima que debe tener una población para entrar en los
   *   resultados
   * @return Lista con las poblaciones encontradas o vacía si no se encontró ninguna
   */
  private static List<Poblacion> buscarPoblaciones(String nombre, int poblacionMinima,
    int poblacionMaxima) {
    
    // Conexion a la base de datos
    ObjectContainer db = null;
    try {
      // Conectamos
      db = Db4o.openFile(RUTA);
      // Hacemos las búsqueda
      ObjectSet<Poblacion> resultado = db.query(new Predicate<Poblacion>() {

        @Override
        public boolean match(Poblacion candidate) {
          return candidate.getNombre().contains(nombre) &&
              candidate.getPoblacionTotal() >= poblacionMinima &&
              candidate.getPoblacionTotal() <= poblacionMaxima;
        }
        
      });
      
      // Copiamos el resultado a la salida
      List<Poblacion> salida = new ArrayList<>();
      for (Poblacion pob: resultado) {
        salida.add(pob);
      }
      // Y devolvemos la salida
      return salida;
    } finally {
      // En cualquier caso intentamos cerrar la conexión
      try {
        db.close();
      } catch (Exception e) {}
    }
  }

  /**
   * Imprime una lista de poblaciones en forma de columnas. El formato es<br>
   * <code>CODIGO NOMBRE EXT P_TOT P_HOM P_MUJ VEHIC LINEAS</code>
   * @param poblaciones Lista con las poblaciones a imprimir
   */
  private static void imprimePoblaciones(List<Poblacion> poblaciones) {
    System.out.println("Poblaciones encontradas");
    System.out.println("CODIGO           NOMBRE             EXT   P_TOT  P_HOM  P_MUJ VEHIC LINEAS");
    System.out.println("--------------------------------------------------------------------------");
    for (Poblacion poblacion: poblaciones) {
      System.out.printf("%5s %-28s %5.1f %6d %6d %6d %5d %6d",
        poblacion.getCodigo(), poblacion.getNombre(), poblacion.getExtension(),
        poblacion.getPoblacionTotal(), poblacion.getPoblacionHombres(), poblacion.getPoblacionMujeres(),
        poblacion.getVehiculos(), poblacion.getLineasTelefonicas());
      System.out.println();
    }
  }
}
