package prog.unidad09.relacion01.ejercicio03;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Predicate;
import prog.unidad09.relacion01.datos.Poblacion;

/**
 * Consulta poblaciones como el ejercicio 02 pero además permite mostrar los resultados ordenados
 */
public class ConsultaPoblacionesConOrdenApp {
  
  // Constantes
  // Ruta a la base de datos
  private static final String RUTA = "db/poblaciones.db4o";

  /**
   * Principal
   * @param args
   */
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
    // Solicita los datos al usuario
    System.out.println("Introduzca los parámetros de búsqueda");
    System.out.print("Texto a buscar en el nombre (vacío para cualquier nombre): ");
    String nombre = sc.nextLine();
    System.out.print("Mostrar sólo poblaciones con un mínimo de habitantes igual a: ");
    int poblacionMinima = Integer.parseInt(sc.nextLine());
    System.out.print("Mostrar sólo poblaciones con un máximo de habitantes igual a: ");
    int poblacionMaxima = Integer.parseInt(sc.nextLine());
    System.out.print("Ordenar por (0=no ordenar, 1=ordenar por nombre ascendente, 2=ordenar por nombre descendente): ");
    int ordenarPor = Integer.parseInt(sc.nextLine());
    
    // Si la ordenación es correcta
    if (ordenarPor == 0 || ordenarPor == 1 || ordenarPor == 2) {
      try {
        // Obtenemos las poblaciones ordenadas
        List<Poblacion> poblaciones = buscarPoblaciones(nombre, poblacionMinima, poblacionMaxima
          , ordenarPor);
        // Y las imprimimos
        imprimePoblaciones(poblaciones);
      } catch (Exception e) {
        System.err.println("Ocurrió un error realizando la búsqueda: " + e);
      }
    } else {
      // Error. ordenación incorrecta
      System.out.printf("Error: La ordenación especificada (%d) no es correcta. Saliendo", ordenarPor);
      return;
    }
  }

  /**
   * Busca poblaciones por nombre y número de habitantes
   * @param nombre Texto a buscar en el nombre de la población (vacío para todas)
   * @param poblacionMinima Población mínima que debe tener una población para entrar en los
   *   resultados
   * @param poblacionMaxima Poblacion máxima que debe tener una población para entrar en los
   *   resultados
   * @param ordenarPor Ordenación a aplicar a los resultados (0 = no ordenar, 1 = ordenar por nombre
   *   ascendente y 2=ordenar por nombre descendente
   * @return Lista con las poblaciones encontradas o vacía si no se encontró ninguna
   */
  private static List<Poblacion> buscarPoblaciones(String nombre, int poblacionMinima,
    int poblacionMaxima, int ordenarPor) {
    
    // Conexion a la base de datos
    ObjectContainer db = null;
    try {
      // Conectamos con la base de datos
      db = Db4o.openFile(RUTA);
      
      // Preparamos el comparador según el criterio de ordenación
      // Inicialmente a no ordenar (ningún comparador)
      Comparator<Poblacion> comparador = null;
      // Si el comparador es ascendente
      if (ordenarPor == 0) {
        comparador = new Comparator<Poblacion>() {

          @Override
          public int compare(Poblacion o1, Poblacion o2) {
            // Devuelve siempre cero. Al ser todos "iguales" no puede ordenarlos
            return 0;
          }
          
        };
      } else if (ordenarPor == 1) {
        // Asignamos el ascendente
        comparador = new Comparator<Poblacion>() {
          
          @Override
          public int compare(Poblacion p1, Poblacion p2) {
            return p1.getNombre().compareTo(p2.getNombre());
          }
        };
      } else if (ordenarPor == 2) {
        // Si es descendente
        comparador = new Comparator<Poblacion>() {
          
          @Override
          public int compare(Poblacion p1, Poblacion p2) {
            return p2.getNombre().compareTo(p1.getNombre());
          }
        };
      } else {
        // Criterio de ordenación inválido
        throw new IllegalArgumentException("Ordenación incorrecta");
      }
      
      // Lanzamos la consulta
      ObjectSet<Poblacion> resultado = db.query(new Predicate<Poblacion>() {

        @Override
        public boolean match(Poblacion candidate) {
          return candidate.getNombre().contains(nombre) &&
              candidate.getPoblacionTotal() >= poblacionMinima &&
              candidate.getPoblacionTotal() <= poblacionMaxima;
        }
        
      }, comparador);
      
      // Copiamos el resultado a la salida
      List<Poblacion> salida = new ArrayList<>();
      for (Poblacion pob: resultado) {
        salida.add(pob);
      }
      // Y devolvemos la salida
      return salida;
    } finally {
      // En cualquier caso intentamos cerrar la conexión
      try {
        db.close();
      } catch (Exception e) {}
    }
  }

  /**
   * Imprime una lista de poblaciones en forma de columnas. El formato es<br>
   * <code>CODIGO NOMBRE EXT P_TOT P_HOM P_MUJ VEHIC LINEAS</code>
   * @param poblaciones Lista con las poblaciones a imprimir
   */
  private static void imprimePoblaciones(List<Poblacion> poblaciones) {
    System.out.println("Poblaciones encontradas");
    System.out.println("CODIGO           NOMBRE             EXT   P_TOT  P_HOM  P_MUJ VEHIC LINEAS");
    System.out.println("--------------------------------------------------------------------------");
    for (Poblacion poblacion: poblaciones) {
      System.out.printf("%5s %-28s %5.1f %6d %6d %6d %5d %6d",
        poblacion.getCodigo(), poblacion.getNombre(), poblacion.getExtension(),
        poblacion.getPoblacionTotal(), poblacion.getPoblacionHombres(), poblacion.getPoblacionMujeres(),
        poblacion.getVehiculos(), poblacion.getLineasTelefonicas());
      System.out.println();
    }
  }
}
