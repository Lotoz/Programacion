package prog.unidad09.relacion01.ejercicio04;

import java.util.Scanner;
import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import prog.unidad09.relacion01.datos.Poblacion;

/**
 * Permite modificar el número de vehiculos o lineas de una sola población
 */
public class ModificarPoblacionApp {

  // Ruta de la base de datos
  private static final String RUTA = "db/poblaciones.db4o";

  /**
   * Principal
   * @param args
   */
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
    // Solicita los datos al usuario
    System.out.println("Introduzca los datos para la modificación");
    System.out.print("Código del pueblo a modificar: ");
    String codigo = sc.nextLine();
    System.out.print("¿Quiere modificar el número de vehiculos (v) o el de líneas telefónicas (l)?: ");
    char campo = sc.nextLine().toLowerCase().charAt(0);
    // Solicita el nuevo valor del campo
    // Primero muestra el prompt correspondiente al campo elegido o un error si la elección fue invalida
    if (campo == 'v') {
      System.out.print("Introduzca el nuevo valor para el campo vehiculos: ");
    } else if (campo == 'l') {
      System.out.print("Introduzca el nuevo valor para el campo líneas telefónicas: ");
    } else {
      // El campo no es válido. Terminamos
      System.err.println("Selección de campo inválida. Terminando");
      return;
    }
    // Y ahora solicita el valor
    int nuevoValor = Integer.parseInt(sc.nextLine());
    
    // Intenta actualizar
    try {
      // Actualiza el valor del campo. Si se encontro?
      if (actualizaPoblacion(codigo, campo, nuevoValor)) {
        System.out.println("El registro se actualizó con éxito");
      } else {
        System.err.println("No existe ninguna población con código " + codigo);
      }
    } catch (Exception e) {
      // Si ocurrió error lo muestra
      System.err.println("Ocurrió un error actualizando la fila: " + e);
    }
  }

  /**
   * Actualiza el valor de un campo (numero de vehiculos o de lineas) de una población
   * @param codigo Código de a población a actualizar
   * @param campo Campo a actualizar ('v' para vehiculos y 'l' para lineas.
   * @param nuevoValor Nuevo valor para el campo
   * @return true si existe la población con el código dado o false si no existe
   */
  private static boolean actualizaPoblacion(String codigo, char campo, int nuevoValor) {

    // Conexion a la base de datos
    ObjectContainer db = null;
    try {
      // Conectamos con la base de datos
      db = Db4o.openFile(RUTA);
      
      // Obtenemos la población empleando Query By Example
      Poblacion ejemplo = new Poblacion(codigo, null, 0, 0, 0, 0, 0, 0);
      ObjectSet<Poblacion> resultado = db.queryByExample(ejemplo);
      
      // Se debió obtener una única población
      if (resultado != null && resultado.size() == 1) {
        // Accedemos a la poblacion
        Poblacion original = resultado.get(0);
        // Según el campo a modificar
        if (campo == 'v') {
          // Modificamos el número de vehiculos
          original.setVehiculos(nuevoValor);
          // Y lo guardamos
          db.store(original);
        } else if (campo == 'l') {
          // Si son las líneas telefónicas, la misma operación
          original.setLineasTelefonicas(nuevoValor);
          db.store(original);
        } else {
          // Si no es ninguno de los dos, parámetro erróneo
          throw new IllegalArgumentException("El campo a modificar no es válido");
        }
        // Devuelve true porque se encontró la poblacion
        return true;
      } else {
        // No se encontró la poblacion
        // devuelve false
        return false;
      }
      
    } finally {
      // En cualquier caso intentamos cerrar la conexión
      try {
        db.close();
      } catch (Exception e) {}
    }
  }

}
