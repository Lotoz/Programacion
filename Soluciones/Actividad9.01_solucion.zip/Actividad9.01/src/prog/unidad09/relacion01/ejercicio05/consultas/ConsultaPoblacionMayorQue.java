package prog.unidad09.relacion01.ejercicio05.consultas;

import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Predicate;
import prog.unidad09.relacion01.datos.Poblacion;

public class ConsultaPoblacionMayorQue implements Consulta<Poblacion> {

  private int poblacion;
  
  public ConsultaPoblacionMayorQue(int poblacion) {
    this.poblacion = poblacion;
  }

  @Override
  public ObjectSet<Poblacion> consulta(ObjectContainer db) {
    // Empleamos consultas nativas
    return db.query(new Predicate<Poblacion>() {

      @Override
      public boolean match(Poblacion candidate) {
        return candidate.getPoblacionTotal() > poblacion;
      }
      
    });
  }


}
