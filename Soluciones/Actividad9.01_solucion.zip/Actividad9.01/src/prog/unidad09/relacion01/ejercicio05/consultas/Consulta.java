package prog.unidad09.relacion01.ejercicio05.consultas;

import java.util.Map;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;

/**
 * Generador de consultas
 */
public interface Consulta<T> {

  /**
   * Realiza una consulta a la base de datos y devuelve el resutado
   */
  ObjectSet<T> consulta(ObjectContainer db);
  
}
