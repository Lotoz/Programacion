package prog.unidad09.relacion01.ejercicio05.consultas;

import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Predicate;
import prog.unidad09.relacion01.datos.Poblacion;

public class ConsultaExtensionMenorQue implements Consulta<Poblacion> {
  
  private double extension;
  
  public ConsultaExtensionMenorQue(double extension) {
    this.extension = extension;
  }

  @Override
  public ObjectSet<Poblacion> consulta(ObjectContainer db) {
    // Empleamos consultas nativas
    return db.query(new Predicate<Poblacion>() {

      @Override
      public boolean match(Poblacion candidate) {
        return candidate.getExtension() < extension;
      }
      
    });
  }

}
