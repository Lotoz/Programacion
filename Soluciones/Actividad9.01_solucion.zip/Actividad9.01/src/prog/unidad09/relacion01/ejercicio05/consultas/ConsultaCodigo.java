package prog.unidad09.relacion01.ejercicio05.consultas;

import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import prog.unidad09.relacion01.datos.Poblacion;

public class ConsultaCodigo implements Consulta<Poblacion> {
  
  private String codigo;
  
  public ConsultaCodigo(String codigo) {
    this.codigo = codigo;
  }

  @Override
  public ObjectSet<Poblacion> consulta(ObjectContainer db) {
    Poblacion ejemplo = new Poblacion(codigo, null, 0, 0, 0, 0, 0, 0);
    return db.queryByExample(ejemplo);
  }

}
