package prog.unidad09.relacion01.ejercicio05;

import java.util.Scanner;
import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import prog.unidad09.relacion01.datos.Poblacion;
import prog.unidad09.relacion01.ejercicio05.consultas.Consulta;
import prog.unidad09.relacion01.ejercicio05.consultas.ConsultaCodigo;
import prog.unidad09.relacion01.ejercicio05.consultas.ConsultaExtensionMenorQue;
import prog.unidad09.relacion01.ejercicio05.consultas.ConsultaPoblacionMayorQue;

/**
 * Elimina poblaciones según criterios determinados.
 */
public class EliminaPoblacionesApp {

  // Constantes
  // Ruta de la base de datos
  private static final String RUTA = "db/poblaciones.db4o";

  /**
   * Principal
   * @param args
   */
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
    // Solicita los datos al usuario
    System.out.println("Eliminación de pueblos");
    System.out.print("¿Desea eliminar por código(c), extensión(e) o población total(p)?: ");
    char campo = sc.nextLine().toLowerCase().charAt(0);
    int poblaciones;
    if (campo == 'c') {
      System.out.print("Código del pueblo a eliminar: ");
      String codigo = sc.nextLine();
      try {
        poblaciones = eliminaPorCodigo(codigo);
      } catch (Exception e) {
        System.err.println("Error eliminando por código");
        return;
      }
    } else if (campo == 'e') {
      System.out.print("Extensión máxima de los pueblos a eliminar (los pueblos con una extensión por debajo de ésta serán eliminados): ");
      double extension = Double.parseDouble(sc.nextLine());
      try {
        poblaciones = eliminaPorExtension(extension);
      } catch (Exception e) {
        System.err.println("Error eliminando por extensión");
        return;
      }
    } else if (campo == 'p') {
      System.out.print("Población mínima de los pueblos a eliminar (los pueblos con una población por encima de ésta serán eliminados): ");
      int poblacion = Integer.parseInt(sc.nextLine());
      try {
        poblaciones = eliminaPorPoblacion(poblacion);
      } catch (Exception e) {
        System.err.println("Error eliminando por población");
        return;
      }
    } else {
      // El campo no es válido. Terminamos
      System.err.println("Selección de campo inválida. Terminando");
      return;
    }
    // Imprime las poblaciones eliminadas
    System.out.println("Se eliminaron " + poblaciones + " poblaciones");
  }

  /**
   * Elimina poblaciones por su código
   * @param codigo Código de la población a eliminar
   * @return Número de poblaciones eliminadas (debería ser 0 ó 1)
   */
  private static int eliminaPorCodigo(String codigo) {
    // Crea la consulta para obtener las poblaciones a eliminar
    Consulta<Poblacion> consulta = new ConsultaCodigo(codigo);
    // Y las elimina
    return eliminaConConsulta(consulta);
  }

  /**
   * Elimina poblaciones por extensión
   * @param extension Extensión mínima que tiene que tener una población para NO ser eliminada
   * @return Número de poblaciones eliminadas
   */
  private static int eliminaPorExtension(double extension) {
    // Consulta para obtener las poblaciones con extensión menor a la dada
    Consulta<Poblacion> consulta = new ConsultaExtensionMenorQue(extension);
    // Eliminamos las poblaciones que se obtengan de la consulta
    return eliminaConConsulta(consulta);
  }

  /**
   * Elimina poblaciones por población total
   * @param poblacion Población máxima que puede tener una población para NO ser eliminada
   * @return Número de poblaciones eliminadas
   */
  private static int eliminaPorPoblacion(int poblacion) {
    // Crea la consulta para obtener las poblaciones con habitantes mayores que el número dado
    Consulta<Poblacion> consulta = new ConsultaPoblacionMayorQue(poblacion);
    // Y elimina las poblacione que se obtengan con la consulta
    return eliminaConConsulta(consulta);
  }

  /**
   * Elimina todas las poblaciones que se obtengan de una consulta determinada
   * @param consulta Consulta que obtiene poblaciones a partir de una base de datos
   * @return Resultado de la consulta
   */
  private static int eliminaConConsulta(Consulta<Poblacion> consulta) {
    // Conexion a la base de datos
    ObjectContainer db = null;
    try {
      // Conectamos con la base de datos
      db = Db4o.openFile(RUTA);
      
      // Obtenemos la población empleando la consulta
      ObjectSet<Poblacion> resultado = consulta.consulta(db);
      
      // Contador de resultados
      int numResultados = 0;
      // Para cada resultado
      for (Poblacion pob: resultado) {
        // Se elimina
        db.delete(pob);
        // Y se cuenta
        numResultados++;
      }
      // Devuelve el número de poblaciones eliminadas
      return numResultados;
      
    } finally {
      // En cualquier caso intentamos cerrar la conexión
      try {
        db.close();
      } catch (Exception e) {}
    }
  }
  
}
