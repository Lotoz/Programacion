package prog.ud08.actividad803.data.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import prog.ud08.actividad803.data.ServicioAccesoDatos;
import prog.ud08.actividad803.data.ServicioAccesoDatosException;
import prog.ud08.actividad803.data.VisitadorVentas;
import prog.ud08.actividad803.modelo.Cliente;
import prog.ud08.actividad803.modelo.Motocicleta;

/**
 * Servicio de acceso a datos para base de datos SQLite
 */
public class ServicioAccesoDatosSQLite implements ServicioAccesoDatos {

  // Constantes
  // URL base SQLite
  private static final String URL_BASE = "jdbc:sqlite:";
  
  // Sentencias
  // Existe cliente con un NIF
  private static final String SQL_GET_CLIENTE = "SELECT * FROM cliente WHERE nif = ?";
  // Actualizar cliente
  private static final String SQL_UPDATE_CLIENTE = "UPDATE cliente SET nombre = ?, apellidos = ?, direccion = ?, nif_recomendado = ? WHERE nif = ?";
  // Añadir motocicleta
  private static final String SQL_ADD_MOTOCICLETA = "INSERT INTO motocicleta(referencia, cilindrada, tipo, precio, fabricante) VALUES (?, ?, ?, ?, ?)";
  // Existe motocicleta con una referencia
  private static final String SQL_EXISTE_MOTOCICLETA = "SELECT * FROM motocicleta WHERE referencia = ?";
  // Añadir venta
  private static final String SQL_ADD_VENTA = "INSERT INTO venta(nif_cliente, referencia_motocicleta, fecha) VALUES (?, ?, ?)";
  // Listado de ventas
  private static final String SQL_LISTADO_VENTAS = "SELECT * FROM cliente INNER JOIN venta ON cliente.nif = venta.nif_cliente INNER JOIN motocicleta ON venta.referencia_motocicleta = motocicleta.referencia ORDER BY fecha DESC, apellidos ASC, nombre ASC";
  // Eliminacion de ventas
  private static final String SQL_DELETE_VENTAS = "DELETE FROM venta WHERE referencia_motocicleta = ?";
  // Eliminacion de motocicleta
  private static final String SQL_DELETE_MOTOCICLETA = "DELETE FROM motocicleta WHERE referencia = ?";

  // Campos
  // Tabla cliente
  private static final String CLI_CAMPO_NIF = "nif";
  private static final String CLI_CAMPO_NOMBRE = "nombre";
  private static final String CLI_CAMPO_APELLIDOS = "apellidos";
  private static final String CLI_CAMPO_DIRECCION = "direccion";
  private static final String CLI_CAMPO_NIF_RECOMENDADO = "nif_recomendado";
  
  // Atributos
  // Ruta de acceso a la base de datos
  private String rutaDb;
  
  /**
   * Constructor
   * @param rutaDb Ruta al archivo con la base de datos SQLite
   */
  public ServicioAccesoDatosSQLite(String rutaDb) {
    this.rutaDb = rutaDb;
  }

  @Override
  public void addMotocicleta(Motocicleta motocicleta) {
    // Crea conexion y sentencia
    try (Connection conexion = getConnection();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_ADD_MOTOCICLETA)) {
      
      // Rellenamos la sentencia con los datos de la motocicleta
      sentencia.setString(1, motocicleta.getReferencia());
      sentencia.setInt(2, motocicleta.getCilindrada());
      sentencia.setString(3, motocicleta.getTipo());
      sentencia.setDouble(4, motocicleta.getPrecio());
      sentencia.setString(5, motocicleta.getFabricante());
      
      // Lanzamos la actualizacion
      sentencia.executeUpdate();
      
    } catch (SQLException e) {
      // Si existe algun error, lanzamos nuestra excepcion
      // Aqui también se entra si ya existe una motocicleta con la misma referencia
      throw new ServicioAccesoDatosException("Error general accediendo a la base de datos: " + e.getMessage());
    }
  }

  @Override
  public int registrarVenta(String nifCliente, String referenciaMotocicleta) {
    // Crea conexion y sentencia
    try (Connection conexion = getConnection();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_ADD_VENTA, Statement.RETURN_GENERATED_KEYS)) {
      
      // Comprobamos si existe cliente con nif y moto con referencia
      if (getClienteByNif(nifCliente) != null && existeMotocicletaConReferencia(referenciaMotocicleta)) {
        // Rellenamos la sentencia con los datos de la venta
        sentencia.setString(1, nifCliente);
        sentencia.setString(2, referenciaMotocicleta);
        sentencia.setString(3, getFechaActual());
        
        // Lanzamos la actualizacion
        if (sentencia.executeUpdate() == 1) {
          // Obtenemos el resultset con las claves generadas
          ResultSet rs = sentencia.getGeneratedKeys();
          // Si hay claves
          if (rs.next()) {
            // Obtiene el código
            int resultado = rs.getInt(1);
            // Cierra el resultset para no dejarlo abierto
            rs.close();
            // Y devuelve el código obtenido
            return resultado;
          } else {
            // No se ha creado la venta
            rs.close();
            throw new ServicioAccesoDatosException("Error. No se ha podido registrar la venta");
          }
        } else {
          // NO se ha insertado la venta
          throw new ServicioAccesoDatosException("Error. No se ha podido registrar la venta");
        }
        
      } else {
        // No existe cliente con el NIF dado o motocicleta con la referencia dada
        throw new ServicioAccesoDatosException("No se puede registrar la venta. No existe cliente con el NIF proporcionado o motocicleta con la referencia proporcionada");
      }
    } catch (SQLException e) {
      // Si existe algun error, lanzamos nuestra excepcion
      throw new ServicioAccesoDatosException("Error general accediendo a la base de datos: " + e.getMessage());
    }
  }

  @Override
  public void getAllVentas(VisitadorVentas visitador) {
    // Crea conexion y sentencia
    try (Connection conexion = getConnection();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_LISTADO_VENTAS)) {
      
        // Lanzamos la consulta
        ResultSet resultado = sentencia.executeQuery();
        
        // Para cada fila o si se indica terminar
        boolean continuar = true;
        while (resultado.next() && continuar) {
          continuar = visitador.visitaFila(resultado);
        }
        // Cerramos el resultado
        resultado.close();
    } catch (SQLException e) {
      // Si existe algun error, lanzamos nuestra excepcion
      throw new ServicioAccesoDatosException("Error general accediendo a la base de datos: " + e.getMessage());
    }
  }

  @Override
  public Cliente getClienteByNif(String nif) {
    // Crea conexion y sentencia
    try (Connection conexion = getConnection();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_GET_CLIENTE)) {
      
      // Rellenamos la sentencia con el nif
      sentencia.setString(1, nif);
      
      // Lanzamos la consulta
      ResultSet rs = sentencia.executeQuery();
      
      // Cliente
      Cliente cliente = null;
      
      // Si se encontró
      if (rs.next()) {
        // Creamos el cliente con los datos de la fila
        cliente = new Cliente(rs.getString(CLI_CAMPO_NIF), rs.getString(CLI_CAMPO_NOMBRE),
            rs.getString(CLI_CAMPO_APELLIDOS), rs.getString(CLI_CAMPO_DIRECCION),
            rs.getString(CLI_CAMPO_NIF_RECOMENDADO));
      }
      
      // Cerramos el resultset en cualquier caso
      rs.close();
      // Y devolvemos el resultado (null o el cliente)
      return cliente;
    } catch (SQLException e) {
      // Si existe algun error, lanzamos nuestra excepcion
      throw new ServicioAccesoDatosException("Error general accediendo a la base de datos: " + e.getMessage());
    }
  }
  
  @Override
  public void updateCliente(Cliente cliente) {
    // Crea conexion y sentencia
    try (Connection conexion = getConnection();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_UPDATE_CLIENTE)) {

      // El nif del recomendado puede ser null o debe ser el de un cliente existente
      if (cliente.getNifRecomendado() == null || getClienteByNif(cliente.getNifRecomendado()) != null) {
  
        // Rellenamos la sentencia con los datos del cliente
        sentencia.setString(1, cliente.getNombre());
        sentencia.setString(2, cliente.getApellidos());
        sentencia.setString(3, cliente.getDireccion());
        sentencia.setString(4, cliente.getNifRecomendado());
        // Por ultimo ponemos el NIF del cliente
        sentencia.setString(5, cliente.getNif());
        // Lanzamos la actualizacion (Si no afecta unicamente a una y nada mas que una fila)
        if (sentencia.executeUpdate() != 1) {
          throw new ServicioAccesoDatosException("No existe cliente con el NIF especificado");
        }
      } else {
        // El NIF del recomendado no es null y no se corresponde con el de un cliente existente
        throw new ServicioAccesoDatosException("El nif de recomendado no es null y no se corresponde con el de un cliente ya existente");
      }
    } catch (SQLException e) {
      // Si existe algun error, lanzamos nuestra excepcion
      throw new ServicioAccesoDatosException("Error general accediendo a la base de datos: " + e.getMessage());
    }
  }

  @Override
  public void deleteMotocicleta(String referencia) {
    // Crea conexion y dos sentencias para eliminar y una para la transaccion
    try (Connection conexion = getConnection();
         PreparedStatement sentenciaEliminaVentas = conexion.prepareStatement(SQL_DELETE_VENTAS);
         PreparedStatement sentenciaEliminaMotocicleta = conexion.prepareStatement(SQL_DELETE_MOTOCICLETA)) {
      
      // Desactivamos commit automático
      conexion.setAutoCommit(false);
      
      // Intentamos eliminar primero las ventas
      sentenciaEliminaVentas.setString(1, referencia);
      sentenciaEliminaVentas.executeUpdate();
      
      // Ahora la motocicleta (Si no existe)
      sentenciaEliminaMotocicleta.setString(1, referencia);
      if (sentenciaEliminaMotocicleta.executeUpdate() != 1) {
        // Si no existia la motocicleta deshacemos la eliminación de las ventas
        conexion.rollback();
        throw new ServicioAccesoDatosException("No existe motocicleta con el NIF proporcionado");
      } else {
        // Si se ha eliminado la motocicleta con éxito confirmamos
        conexion.commit();
      }
      
      
    } catch (SQLException e) {
      // Si existe algun error, lanzamos nuestra excepcion
      throw new ServicioAccesoDatosException("Error general accediendo a la base de datos: " + e.getMessage());
    }
  }

  /**
   * Obtiene una conexión a la base de datos
   * @return Conexion a la base de datos
   * @throws SQLException Si se produce cualquier error obteniendo la conexión
   */
  private Connection getConnection() throws SQLException {
    // Intenta obtener la conexión empleando la ruta al archivo
    return DriverManager.getConnection(URL_BASE + rutaDb);
  }

  /**
   * Comprueba si existe o no una motocicleta con la referencia proporcionada
   * @param referencia Referencia de la motociclea a buscar
   * @return true si existe una motocicleta con la referencia proporcionada. false si no
   */
  private boolean existeMotocicletaConReferencia(String referencia) {
    // Crea conexion y sentencia
    try (Connection conexion = getConnection();
         PreparedStatement sentencia = conexion.prepareStatement(SQL_EXISTE_MOTOCICLETA)) {
      
      // Rellenamos la sentencia con la referencia
      sentencia.setString(1, referencia);
      
      // Lanzamos la consulta
      ResultSet rs = sentencia.executeQuery();
      // Almacenamos si hay o no resultados
      boolean resultado = rs.next();
      // Cerramos el ResultSet
      rs.close();
      // Y devolvemos el resultado
      return resultado;
    } catch (SQLException e) {
      // Si existe algun error, lanzamos nuestra excepcion
      throw new ServicioAccesoDatosException("Error general accediendo a la base de datos: " + e.getMessage());
    }
  }

  /**
   * Obtiene la fecha actual en formato aaaa-mm-dd
   * @return Fecha actual
   */
  private String getFechaActual() {
    // Devolvemos la fecha formateada
    return LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
  }

}
