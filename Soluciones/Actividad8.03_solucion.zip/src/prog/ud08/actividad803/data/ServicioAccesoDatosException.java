package prog.ud08.actividad803.data;

/**
 * Excepcion del paquete
 */
@SuppressWarnings("serial")
public class ServicioAccesoDatosException extends RuntimeException {

  public ServicioAccesoDatosException(String message) {
    super(message);
  }
}
