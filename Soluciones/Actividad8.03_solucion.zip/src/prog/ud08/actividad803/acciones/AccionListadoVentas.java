package prog.ud08.actividad803.acciones;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import prog.common.app.consola.Consola;
import prog.ud08.actividad803.data.ServicioAccesoDatosException;
import prog.ud08.actividad803.data.VisitadorVentas;

/**
 * Accion para listar las ventas
 */
public class AccionListadoVentas extends AccionBase {

  /**
   * Constructor con titulo
   * @param titulo Titulo de la acción
   */
  public AccionListadoVentas(String titulo) {
    super(titulo);
  }

  @Override
  public void ejecutar() {
    // Accedemos a la consola
    Consola consola = Consola.getConsola();
    
    // Titulo
    imprimeTitulo();
    
    // Aqui se almacenan las lineas del listado
    List<String> lineas = new ArrayList<>();
    
    try {
      // Consultar las ventas
      // Para ellos llamamos a getAllVentas y le pasamos este Visitador que toma cada fila, genera
      // la línea de texto con los datos de dicha fila y la añade a la lista
      getServicioAccesoDatos().getAllVentas(new VisitadorVentas() {
        
        @Override
        public boolean visitaFila(ResultSet resultado) {
          try {
            // Formatea la linea con los datos de la fila y la almacena
            lineas.add(String.format(Locale.US, "%9s %-30s %-15s %-20s %5d %10.2f %s",
                resultado.getString("nif"),
                resultado.getString("apellidos") + ", " + resultado.getString("nombre"),
                resultado.getString("referencia"), resultado.getString("fabricante"),
                resultado.getInt("cilindrada"), resultado.getDouble("precio"),
                resultado.getString("fecha")));
              // Seguimos procesando
            return true;
          } catch (SQLException e) {
            // En caso de excepción, para inmediatamente
            return false;
          }
        }
      });
    } catch (ServicioAccesoDatosException e) {
      // Si Hay algún error muestra mensaje
      consola.escribeLinea("Error accediendo al listado de ventas");
    }

    // Si la lista no está vacía (había ventas)
    if (!lineas.isEmpty()) {
      // Imprime la cabecera
      consola.escribeLinea("NIF       Apellidos,Nombre               Referencia      Fabricante          Cilind.  Precio   Fecha Venta");
      // Y cada línea
      for (String linea: lineas) {
        consola.escribeLinea(linea);
      }
    } else {
      // No hay ventas. Escribe mensaje
      consola.escribeLinea("No hay ventas");
    }
    
  }

}
