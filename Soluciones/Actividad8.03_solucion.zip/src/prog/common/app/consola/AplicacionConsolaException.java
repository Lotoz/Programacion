package prog.common.app.consola;

/**
 * Excepcion del paquete
 */
@SuppressWarnings("serial")
public class AplicacionConsolaException extends RuntimeException {

  public AplicacionConsolaException(String message) {
    super(message);
  }
}
