package prog.unidad08.relacion02.proveedor;

/**
 * Excepcion del paquete
 */
public class ProveedorAlmacenamientoEmpresaException extends RuntimeException {

  /**
   * Constructor con mensaje
   * @param string Mensaje de la excepción
   */
  public ProveedorAlmacenamientoEmpresaException(String string) {
    // TODO Auto-generated constructor stub
  }

  private static final long serialVersionUID = 1L;

}
